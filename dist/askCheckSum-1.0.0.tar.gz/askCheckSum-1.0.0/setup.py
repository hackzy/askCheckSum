from setuptools import setup, find_packages


setup(name='askCheckSum',
      version = '1.0.0',
      description = 'askCheckSum',
      packages=find_packages(),
      author_email='hufazyj@gmail.com',
      author='hackzy',
)
